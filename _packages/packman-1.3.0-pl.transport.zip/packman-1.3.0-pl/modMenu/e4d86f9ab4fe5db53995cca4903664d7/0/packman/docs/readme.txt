----------------------------
Extension: PackMan
----------------------------
Version: 1.3.0
Since: June 11th, 2010 updated August 2016
Author: Shaun McCormick <shaun@modxcms.com> modified by Mike Barton <mike@mjb123.uk>
License: GNU GPLv2 (or later at your option)

This component is an assistance tool for building transport
packages for your Templates, Snippets, Chunks and more.

Simply run the manager page, select the appropriate options,
and click Export Transport Package. The file will then be downloaded to your
browser.

Thanks for using MODx Revolution.

Shaun McCormick
shaun@modxcms.com